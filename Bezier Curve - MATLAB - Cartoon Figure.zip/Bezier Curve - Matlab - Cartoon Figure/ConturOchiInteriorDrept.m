function [X, Y] = ConturOchiInteriorDrept(numPuncte)
    % vectorii de coordonate
    X = [];
    Y = [];
    
    
   puncteControl1 = [
    1.603, 1.503; 
    2.223, 2.556; 
    3.105, 1;  
    2.69, 0.494;  
];


puncteControl2 = [
    1.603, 1.503; 
    1.228, -0.37;
    2.124, -0.61; 
    2.69, 0.494;   
];
   
    [BX1, BY1] = generareCurbaBezier(puncteControl1, numPuncte);
    X = [X, BX1, NaN]; % NaN pentru a separa cele doua segmente
    Y = [Y, BY1, NaN];


    [BX2, BY2] = generareCurbaBezier(puncteControl2, numPuncte);
    X = [X, BX2];
    Y = [Y, BY2];
end

function [BX, BY] = generareCurbaBezier(puncteControl, numPuncte)
    BX = zeros(1, numPuncte);
    BY = zeros(1, numPuncte);
    
    for i = 1:numPuncte
        t = (i-1) / (numPuncte-1);
        B = (1-t)^3 * puncteControl(1,:) + ...
            3*(1-t)^2 * t * puncteControl(2,:) + ...
            3*(1-t) * t^2 * puncteControl(3,:) + ...
            t^3 * puncteControl(4,:);
        
        BX(i) = B(1);
        BY(i) = B(2);
    end
end
