function [X, Y] = GheareBratStang(numPuncte)
    % vectorii de coordonate
    X = [];
    Y = [];
    
    %  punctele de control pentru fiecare gheara
    puncteControlGheara1 = [
        -1.018, -5.65;
        -1.134, -6.08;
        -1.284, -6.045;
        -1.153, -5.6
    ];
    
    puncteControlGheara2 = [
        -0.608, -5.657;
        -0.523, -6.083;
        -0.68, -6.614;
        -0.774, -5.718
    ];
    
    puncteControlGheara3 = [
        -0.41, -5.368;
        -0.034, -5.787;
        -0.215, -5.872;
        -0.516, -5.543
    ];
    
    % Adaugam fiecare gheara la vectorii de coordonate
    gheare = {puncteControlGheara1, puncteControlGheara2, puncteControlGheara3};
    for i = 1:length(gheare)
        [BX, BY] = generareCurbaBezier(gheare{i}, numPuncte);
        X = [X, BX, NaN]; 
        Y = [Y, BY, NaN];
    end
end

function [BX, BY] = generareCurbaBezier(puncteControl, numPuncte)
    BX = zeros(1, numPuncte);
    BY = zeros(1, numPuncte);
    
    for i = 1:numPuncte
        t = (i-1) / (numPuncte-1);
        B = (1-t)^3 * puncteControl(1,:) + ...
            3*(1-t)^2 * t * puncteControl(2,:) + ...
            3*(1-t) * t^2 * puncteControl(3,:) + ...
            t^3 * puncteControl(4,:);
        
        BX(i) = B(1);
        BY(i) = B(2);
    end
end
