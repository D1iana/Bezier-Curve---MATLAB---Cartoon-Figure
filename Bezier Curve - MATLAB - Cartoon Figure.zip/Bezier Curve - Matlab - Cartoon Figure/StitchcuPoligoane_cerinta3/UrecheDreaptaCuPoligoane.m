function [BX, BY, PCX, PCY] = UrecheDreaptaCuPoligoane(numPuncte)

    BX = [];
    BY = [];
    PCX = []; 
    PCY = []; 

    puncteControl = {
        [2.716, 4.9; 2.867, 2.87; 2.932, 2.042; 2.725, 1.676];
        [2.716, 4.9; 2.648, 5.504; 3.026, 5.782; 3.817, 4.86];
        [4.33, 3.323; 4.35, 3.454; 4.213, 4.198; 3.817, 4.86];
        [4.33, 3.323; 4.333, 3.085; 4.44, 2.668; 4.145, 1.745];
        [3.926, 1.234; 3.533, 1.748; 3.618, 1.778; 4.145, 1.745];
        [3.926, 1.234; 3.658, 0.774; 3.556, 0.607; 3.052, 0.223]
    };

  for i = 1:length(puncteControl)
        segment = puncteControl{i};
        

        PCX = [PCX, segment(:,1)', NaN];  
        PCY = [PCY, segment(:,2)', NaN];
        
  
        [curbaX, curbaY] = generareCurbaBezier(segment, numPuncte);
        BX = [BX, curbaX, NaN];  
        BY = [BY, curbaY, NaN];
    end
end