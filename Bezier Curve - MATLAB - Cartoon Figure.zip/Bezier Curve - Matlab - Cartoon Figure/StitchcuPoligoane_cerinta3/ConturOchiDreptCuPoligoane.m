function [BX, BY, PCX, PCY] = ConturOchiDreptCuPoligoane(numPuncte)

    BX = [];
    BY = [];
    PCX = []; 
    PCY = [];

 puncteControl = {
      [
        1.40, 0.05;
        1.40, -0.057;
        1.25, 2.50;
        1.98, 2.73
    ];
    [
        1.40, 0.05;
        1.35, -0.532;
        2.70, -0.44;
        2.999, 0.756
    ];
    };
    
  for i = 1:length(puncteControl)
        segment = puncteControl{i};
        
        PCX = [PCX, segment(:,1)', NaN];  
        PCY = [PCY, segment(:,2)', NaN];
        
   
        [curbaX, curbaY] = generareCurbaBezier(segment, numPuncte);
        BX = [BX, curbaX, NaN]; 
        BY = [BY, curbaY, NaN];
    end
end