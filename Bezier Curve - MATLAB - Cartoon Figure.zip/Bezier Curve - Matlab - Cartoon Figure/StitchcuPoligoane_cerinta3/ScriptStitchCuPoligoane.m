numPuncte = 100;
figure; 
hold on;

%apelare functii
[capBX, capBY, capPCX, capPCY] = CapStitchCuPoligoane(numPuncte);
[urecheDreaptaBX, urecheDreaptaBY, urecheDreaptaPCX, urecheDreaptaPCY] = UrecheDreaptaCuPoligoane(numPuncte);
[urecheStangaBX, urecheStangaBY, urecheStangaPCX, urecheStangaPCY] = UrecheStangaCuPoligoane(numPuncte);
[bratStangBX, bratStangBY, bratStangPCX, bratStangPCY] = BratStangCuPoligoane(numPuncte);
[bratDreptBX, bratDreptBY, bratDreptPCX, bratDreptPCY] = BratDreptCuPoligoane(numPuncte);
[piciorStangBX, piciorStangBY, piciorStangPCX, piciorStangPCY] = PiciorStangCuPoligoane(numPuncte);
[piciorDreptBX, piciorDreptBY, piciorDreptPCX, piciorDreptPCY] = PiciorDreptCuPoligoane(numPuncte);
[conturOchiStangBX, conturOchiStangBY, conturOchiStangPCX, conturOchiStangPCY] = ConturOchiStangCuPoligoane(numPuncte);
[conturOchiDreptBX, conturOchiDreptBY, conturOchiDreptPCX, conturOchiDreptPCY] = ConturOchiDreptCuPoligoane(numPuncte);
[linieLegaturaBX, linieLegaturaBY, linieLegaturaPCX, linieLegaturaPCY] = LinieLegaturaPiciorCuPoligoane(numPuncte);
[conturOchiInteriorDreptCuPoligoaneBX,conturOchiInteriorDreptCuPoligoaneBY,conturOchiInteriorDreptCuPoligoanePCX,conturOchiInteriorDreptCuPoligoanePCY] = ConturOchiInteriorDreptCuPoligoane(numPuncte);
[conturOchiInteriorStangCuPoligoaneBX,conturOchiInteriorStangCuPoligoaneBY,conturOchiInteriorStangCuPoligoanePCX,conturOchiInteriorStangCuPoligoanePCY] = ConturOchiInteriorStangCuPoligoane(numPuncte);
[nasBX, nasBY, nasPCX, nasPCY] = NasCuPoligoane(numPuncte);
[guraBX, guraBY, guraPCX, guraPCY] = GuraCuPoligoane(numPuncte);
[gheareBratDreptBX, gheareBratDreptBY, gheareBratDreptPCX, gheareBratDreptPCY] = GheareBratDreptCuPoligoane(numPuncte);
[gheareBratStangBX, gheareBratStangBY, gheareBratStangPCX, gheareBratStangPCY] = GheareBratStangCuPoligoane(numPuncte);
[piciorInteriorStangBX, piciorInteriorStangBY, piciorInteriorStangPCX, piciorInteriorStangPCY] = PiciorInteriorStangCuPoligoane(numPuncte);
[piciorInteriorDreptBX, piciorInteriorDreptBY, piciorInteriorDreptPCX, piciorInteriorDreptPCY] = PiciorInteriorDreptCuPoligoane(numPuncte);
[linieBurticaBX, linieBurticaBY, linieBurticaPCX, linieBurticaPCY] = LinieBurticaCuPoligoane(numPuncte);

%plotare elemente
plot(capBX, capBY, 'k','LineWidth',2); %  curba Bezier pentru cap
plot(capPCX, capPCY, 'r--', 'LineWidth', 0.5); % poligonul de control pentru cap
plot(urecheDreaptaBX, urecheDreaptaBY, 'k','LineWidth', 2);
plot(urecheDreaptaPCX, urecheDreaptaPCY, 'r--', 'LineWidth', 0.5);
plot(urecheStangaBX, urecheStangaBY,'k', 'LineWidth', 2);
plot(urecheStangaPCX, urecheStangaPCY, 'r--', 'LineWidth', 0.5);
plot(bratStangBX, bratStangBY,'k', 'LineWidth', 2);
plot(bratStangPCX, bratStangPCY, 'r--', 'LineWidth', 0.5);
plot(bratDreptBX, bratDreptBY, 'k','LineWidth', 2);
plot(bratDreptPCX, bratDreptPCY, 'r--', 'LineWidth', 0.5);
plot(piciorStangBX, piciorStangBY, 'k','LineWidth', 2);
plot(piciorStangPCX, piciorStangPCY, 'r--', 'LineWidth', 0.5);
plot(piciorDreptBX, piciorDreptBY, 'k','LineWidth', 2);
plot(piciorDreptPCX, piciorDreptPCY, 'r--', 'LineWidth', 0.5);
plot(conturOchiStangBX, conturOchiStangBY,'k', 'LineWidth', 2);
plot(conturOchiStangPCX, conturOchiStangPCY, 'r--', 'LineWidth', 0.5);
plot(conturOchiDreptBX, conturOchiDreptBY, 'k','LineWidth', 2);
plot(conturOchiDreptPCX, conturOchiDreptPCY, 'r--', 'LineWidth', 0.5);
plot(linieLegaturaBX, linieLegaturaBY,'k', 'LineWidth', 2);
plot(linieLegaturaPCX, linieLegaturaPCY, 'r--', 'LineWidth', 0.5);
plot(conturOchiInteriorDreptCuPoligoaneBX,conturOchiInteriorDreptCuPoligoaneBY,'k', 'LineWidth', 2);
plot(conturOchiInteriorDreptCuPoligoanePCX,conturOchiInteriorDreptCuPoligoanePCY, 'r--', 'LineWidth', 0.5);
plot(conturOchiInteriorStangCuPoligoaneBX,conturOchiInteriorStangCuPoligoaneBY, 'k','LineWidth', 2);
plot(conturOchiInteriorStangCuPoligoanePCX,conturOchiInteriorStangCuPoligoanePCY, 'r--', 'LineWidth', 0.5);
plot(nasBX, nasBY, 'k','LineWidth', 2);
plot(nasPCX, nasPCY, 'r--', 'LineWidth', 0.5); 
plot(guraBX, guraBY, 'k', 'LineWidth', 2);
plot(guraPCX, guraPCY, 'r--', 'LineWidth', 0.5); 
plot(gheareBratDreptBX, gheareBratDreptBY, 'k','LineWidth', 2);
plot(gheareBratDreptPCX, gheareBratDreptPCY, 'r--', 'LineWidth', 0.5);  
plot(gheareBratStangBX, gheareBratStangBY,'k', 'LineWidth', 2);
plot(gheareBratStangPCX, gheareBratStangPCY, 'r--', 'LineWidth', 0.5);  
plot(piciorInteriorStangBX, piciorInteriorStangBY, 'k','LineWidth', 2);
plot(piciorInteriorStangPCX, piciorInteriorStangPCY, 'r--', 'LineWidth', 0.5);
plot(piciorInteriorDreptBX, piciorInteriorDreptBY, 'k','LineWidth', 2);
plot(piciorInteriorDreptPCX, piciorInteriorDreptPCY, 'r--', 'LineWidth', 0.5);
plot(linieBurticaBX, linieBurticaBY,'k', 'LineWidth', 2);
plot(linieBurticaPCX, linieBurticaPCY, 'r--', 'LineWidth', 0.5);



scatter(capPCX(1:end-1:end), capPCY(1:end-1:end), 'red', 'filled'); %Primul și ultimul punct sunt pline
scatter(capPCX(2:end-2), capPCY(2:end-2), 'k'); % Punctele intermediare sunt goale
scatter(urecheDreaptaPCX(1:end-1:end), urecheDreaptaPCY(1:end-1:end), 'red', 'filled');
scatter(urecheDreaptaPCX(2:end-2), urecheDreaptaPCY(2:end-2), 'k');
scatter(urecheStangaPCX(1:end-1:end), urecheStangaPCY(1:end-1:end), 'red', 'filled');
scatter(urecheStangaPCX(2:end-2), urecheStangaPCY(2:end-2), 'k');
scatter(bratStangPCX(1:end-1:end), bratStangPCY(1:end-1:end), 'red', 'filled');
scatter(bratStangPCX(2:end-2), bratStangPCY(2:end-2), 'k');
scatter(bratDreptPCX(1:end-1:end), bratDreptPCY(1:end-1:end), 'red', 'filled');
scatter(bratDreptPCX(2:end-2), bratDreptPCY(2:end-2), 'k');
scatter(piciorStangPCX(1:end-1:end), piciorStangPCY(1:end-1:end), 'red', 'filled');
scatter(piciorStangPCX(2:end-2), piciorStangPCY(2:end-2), 'k');
scatter(piciorDreptPCX(1:end-1:end), piciorDreptPCY(1:end-1:end), 'red', 'filled');
scatter(piciorDreptPCX(2:end-2), piciorDreptPCY(2:end-2), 'k');
scatter(conturOchiStangPCX(1:end-1:end), conturOchiStangPCY(1:end-1:end), 'red', 'filled');
scatter(conturOchiStangPCX(2:end-2), conturOchiStangPCY(2:end-2), 'k');
scatter(conturOchiDreptPCX(1:end-1:end), conturOchiDreptPCY(1:end-1:end), 'red', 'filled');
scatter(conturOchiDreptPCX(2:end-2), conturOchiDreptPCY(2:end-2), 'k');
scatter(linieLegaturaPCX(1:end-1:end), linieLegaturaPCY(1:end-1:end), 'r', 'filled'); 
scatter(linieLegaturaPCX(2:end-2), linieLegaturaPCY(2:end-2),'k'); 
scatter(conturOchiInteriorDreptCuPoligoanePCX(1:end-1:end), conturOchiInteriorDreptCuPoligoanePCY(1:end-1:end), 'r', 'filled'); % Primul punct
scatter(conturOchiInteriorDreptCuPoligoanePCX(2:end-2), conturOchiInteriorDreptCuPoligoanePCY(2:end-2),'k'); % Ultimul punct
scatter(conturOchiInteriorStangCuPoligoanePCX(1:end-1:end), conturOchiInteriorStangCuPoligoanePCY(1:end-1:end), 'r', 'filled'); % Primul punct
scatter(conturOchiInteriorStangCuPoligoanePCX(2:end-2), conturOchiInteriorStangCuPoligoanePCY(2:end-2),'k'); % Ultimul punct
scatter(nasPCX(1:end-1:end), nasPCY(1:end-1:end), 'red', 'filled'); 
scatter(nasPCX(2:end-2), nasPCY(2:end-2), 'k');
scatter(guraPCX(1:end-1:end), guraPCY(1:end-1:end), 'red', 'filled'); 
scatter(guraPCX(2:end-2), guraPCY(2:end-2), 'k');
scatter(gheareBratDreptPCX(1:end-1:end), gheareBratDreptPCY(1:end-1:end), 'red', 'filled'); 
scatter(gheareBratDreptPCX(2:end-2), gheareBratDreptPCY(2:end-2), 'k');
scatter(gheareBratStangPCX(1:end-1:end), gheareBratStangPCY(1:end-1:end), 'red', 'filled'); 
scatter(gheareBratStangPCX(2:end-2), gheareBratStangPCY(2:end-2), 'k');
scatter(piciorInteriorStangPCX(1:end-1:end), piciorInteriorStangPCY(1:end-1:end), 'red', 'filled');
scatter(piciorInteriorStangPCX(2:end-2), piciorInteriorStangPCY(2:end-2), 'k');
scatter(piciorInteriorDreptPCX(1:end-1:end), piciorInteriorDreptPCY(1:end-1:end), 'red', 'filled');
scatter(piciorInteriorDreptPCX(2:end-2), piciorInteriorDreptPCY(2:end-2), 'k');
scatter(linieBurticaPCX(1:end-1:end), linieBurticaPCY(1:end-1:end), 'r', 'filled'); % Primul punct
scatter(linieBurticaPCX(2:end-2), linieBurticaPCY(2:end-2),'k'); % Ultimul punct

hold off;
axis equal;
title('Stitch - Poligoane de Control');
