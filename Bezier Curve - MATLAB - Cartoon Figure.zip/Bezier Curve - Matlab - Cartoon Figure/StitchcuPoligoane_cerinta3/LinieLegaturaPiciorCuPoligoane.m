function [BX, BY, PCX, PCY] = LinieLegaturaPiciorCuPoligoane(numPuncte)
 
    BX = [];
    BY = [];
    PCX = []; 
    PCY = []; 


puncteControl ={ [-0.375 -5.33; -0.12 -5.34; 0.143 -5.33; 0.40 -5.364]};


  for i = 1:length(puncteControl)
        segment = puncteControl{i};
        

        PCX = [PCX, segment(:,1)', NaN];  
        PCY = [PCY, segment(:,2)', NaN];
        
  
        [curbaX, curbaY] = generareCurbaBezier(segment, numPuncte);
        BX = [BX, curbaX, NaN];  
        BY = [BY, curbaY, NaN];
    end
end