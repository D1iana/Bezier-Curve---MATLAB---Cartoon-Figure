function [BX, BY, PCX, PCY] = BratDreptCuPoligoane(numPuncte)
    % vectorii de coordonate pentru curba Bezier si pentru punctele poligonului de control
    BX = [];
    BY = [];
    PCX = []; % coordonatele X ale punctelor de control
    PCY = []; % coordonatele Y ale punctelor de control
   

   puncteControl = {
        [1.55, -4.89; 2.01, -1.07; 0.39, 0.98; 0.33, -5.13];
        [1.55, -4.89; 0.9, -6.38; 0.39, -5.51; 0.33, -5.13]
    };

  for i = 1:length(puncteControl)
        segment = puncteControl{i};
        
        % Adaugam coordonatele punctelor de control la PCX si PCY
        PCX = [PCX, segment(:,1)', NaN];  %  NaN pentru separare in grafic
        PCY = [PCY, segment(:,2)', NaN];
        
        %adaugam coordonatele curbei Bezier la BX si BY
        [curbaX, curbaY] = generareCurbaBezier(segment, numPuncte);
        BX = [BX, curbaX, NaN];  % NaN pentru separare
        BY = [BY, curbaY, NaN];
    end
end