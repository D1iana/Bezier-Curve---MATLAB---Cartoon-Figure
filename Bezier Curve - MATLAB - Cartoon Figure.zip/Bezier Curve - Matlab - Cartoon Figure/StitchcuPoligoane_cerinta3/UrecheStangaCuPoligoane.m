function [BX, BY, PCX, PCY] = UrecheStangaCuPoligoane(numPuncte)
    BX = [];
    BY = [];
    PCX = []; %coordonatele X ale punctelor de control
    PCY = []; % coordonatele Y ale punctelor de control
    
   puncteControl = {
        [-2.82, 4.777; -2.42, 4.224; -2.825, 2.13; -2.306, 1.24];
        [-2.82, 4.777; -3.134, 4.873; -3.58, 4.435; -3.81, 3.627];
        [-3.896, 2.995; -3.557, 3.22; -3.357, 3.003; -3.81, 3.627];
        [-3.896, 2.995; -4.073, 1.304; -3.38, 0.45; -2.42, -0.22]
    };

  for i = 1:length(puncteControl)
        segment = puncteControl{i};
        
        % adaugam coordonatele punctelor de control la PCX si PCY
        PCX = [PCX, segment(:,1)', NaN];  % NaN pentru separare 
        PCY = [PCY, segment(:,2)', NaN];
        
        % Calculam si adaugam coordonatele curbei Bezier la BX si BY
        [curbaX, curbaY] = generareCurbaBezier(segment, numPuncte);
        BX = [BX, curbaX, NaN];  % NaN pentru separare
        BY = [BY, curbaY, NaN];
    end
end