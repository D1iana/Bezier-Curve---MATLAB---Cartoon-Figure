function [BX, BY, PCX, PCY] = PiciorDreptCuPoligoane(numPuncte)
    %  vectorii de coordonate pentru curba Bezier si pentru punctele poligonului de control
    BX = [];
    BY = [];
    PCX = []; % coordonatele X ale punctelor de control
    PCY = []; % coordonatele Y ale punctelor de control
 
 puncteControl = {
        [1.56, -2.54; 1.91, -4.66; 1.916, -3.09; 3.1, -4.035];
        [1.36, -5.41; 2.17, -5.63; 4.05, -6.09; 3.1, -4.035]
    };
    

  for i = 1:length(puncteControl)
        segment = puncteControl{i};
        
        % adaugam coordonatele punctelor de control la PCX si PCY
        PCX = [PCX, segment(:,1)', NaN];  % NaN pentru separare 
        PCY = [PCY, segment(:,2)', NaN];
        
        % calculam si adaugam coordonatele curbei Bezier la BX si BY
        [curbaX, curbaY] = generareCurbaBezier(segment, numPuncte);
        BX = [BX, curbaX, NaN];  % NaN pentru separare
        BY = [BY, curbaY, NaN];
    end
end