function [BX, BY, PCX, PCY] = ConturOchiInteriorStangCuPoligoane(numPuncte)

    BX = [];
    BY = [];
    PCX = []; 
    PCY = []; 
 

  puncteControl = {
 [
    -1.764, 1.436;
    -3.463, 0.256;
    -0.475, -1.777;
     -1.117, 1.004
];
[
    -1.764, 1.436;
    -1.514, 1.554;
    -1.217, 1.263;
    -1.117, 1.004 
];
    };
    
  for i = 1:length(puncteControl)
        segment = puncteControl{i};
        

        PCX = [PCX, segment(:,1)', NaN]; 
        PCY = [PCY, segment(:,2)', NaN];
        

        [curbaX, curbaY] = generareCurbaBezier(segment, numPuncte);
        BX = [BX, curbaX, NaN];  
        BY = [BY, curbaY, NaN];
    end
end