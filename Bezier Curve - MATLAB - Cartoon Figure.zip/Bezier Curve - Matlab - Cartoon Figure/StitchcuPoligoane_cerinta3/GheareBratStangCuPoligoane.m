function [BX, BY, PCX, PCY] = GheareBratStangCuPoligoane(numPuncte)

    BX = [];
    BY = [];
    PCX = []; 
    PCY = []; 
 
 puncteControl = {
 [
         -1.018, -5.65;
        -1.134, -6.08;
        -1.284, -6.045;
        -1.153, -5.6
];
[
       -0.608, -5.657;
        -0.523, -6.083;
        -0.68, -6.614;
        -0.774, -5.718
];
[       -0.41, -5.368;
        -0.034, -5.787;
        -0.215, -5.872;
        -0.516, -5.543
    ];
    };
    

  for i = 1:length(puncteControl)
        segment = puncteControl{i};
        
   
        PCX = [PCX, segment(:,1)', NaN];  
        PCY = [PCY, segment(:,2)', NaN];
        
        [curbaX, curbaY] = generareCurbaBezier(segment, numPuncte);
        BX = [BX, curbaX, NaN];  
        BY = [BY, curbaY, NaN];
    end
end