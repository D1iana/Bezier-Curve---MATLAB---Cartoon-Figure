function [BX, BY, PCX, PCY] = GuraCuPoligoane(numPuncte)
 
    BX = [];
    BY = [];
    PCX = []; 
    PCY = [];

 puncteControl = {
 [
     -1.855, -0.953;
     -1.7, -0.167;
     -0.64, -1.535;
      1.57, -0.65
];
[
      2.596, -0.62;
      2.38, -0.167;
      2.035, -0.5;
      1.57, -0.65
];
    };
    

  for i = 1:length(puncteControl)
        segment = puncteControl{i};

        PCX = [PCX, segment(:,1)', NaN]; 
        PCY = [PCY, segment(:,2)', NaN];
        
        
        [curbaX, curbaY] = generareCurbaBezier(segment, numPuncte);
        BX = [BX, curbaX, NaN]; 
        BY = [BY, curbaY, NaN];
    end
end