function [BX, BY, PCX, PCY] = LinieBurticaCuPoligoane(numPuncte)

    BX = [];
    BY = [];
    PCX = []; 
    PCY = []; 

 puncteControl = {
 [
        -0.33, -4.60;
        -0.17, -5.17;
        0.34, -5.17;
        0.33, -4.85
];

    };
    
 for i = 1:length(puncteControl)
        segment = puncteControl{i};
        
     
        PCX = [PCX, segment(:,1)', NaN];  
        PCY = [PCY, segment(:,2)', NaN];
    
        [curbaX, curbaY] = generareCurbaBezier(segment, numPuncte);
        BX = [BX, curbaX, NaN]; 
        BY = [BY, curbaY, NaN];
    end
end
