function [BX, BY, PCX, PCY] = ConturOchiStangCuPoligoane(numPuncte)

    BX = [];
    BY = [];
    PCX = []; 
    PCY = [];

puncteControl = {
        [
        -0.87, -0.02;
        -0.93, 0.615;
        -0.925, 2.804;
        -1.72, 2.39
    ];
        [
        -0.87, -0.02;
        -0.933, -0.754;
        -2.05, -0.76;
        -2.40, 0.015 
    ];
    };
    
 
  for i = 1:length(puncteControl)
        segment = puncteControl{i};
        
      
        PCX = [PCX, segment(:,1)', NaN]; 
        PCY = [PCY, segment(:,2)', NaN];
        
    
        [curbaX, curbaY] = generareCurbaBezier(segment, numPuncte);
        BX = [BX, curbaX, NaN];  
        BY = [BY, curbaY, NaN];
    end
end