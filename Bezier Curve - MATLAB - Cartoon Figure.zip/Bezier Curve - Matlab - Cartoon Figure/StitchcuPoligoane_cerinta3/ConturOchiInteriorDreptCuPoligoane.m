function [BX, BY, PCX, PCY] = ConturOchiInteriorDreptCuPoligoane(numPuncte)

    BX = [];
    BY = [];
    PCX = []; 
    PCY = []; 

puncteControl = {
 [
    1.603, 1.503; 
    2.223, 2.556; 
    3.105, 1; 
    2.69, 0.494; 
];
[
    1.603, 1.503;
    1.228, -0.37; 
    2.124, -0.61;  
    2.69, 0.494;   
];
    };
    

  for i = 1:length(puncteControl)
        segment = puncteControl{i};
        
        PCX = [PCX, segment(:,1)', NaN];  
        PCY = [PCY, segment(:,2)', NaN];
        

        [curbaX, curbaY] = generareCurbaBezier(segment, numPuncte);
        BX = [BX, curbaX, NaN]; 
        BY = [BY, curbaY, NaN];
    end
end