function [BX, BY, PCX, PCY] = PiciorInteriorStangCuPoligoane(numPuncte)
 
    BX = [];
    BY = [];
    PCX = [];
    PCY = []; 

 puncteControl = {
 [
         -2.29, -5.56;
        -2.03, -5.216;
        -1.828, -4.843;
        -2.15, -4.276
];
[
         -2.960, -3.920;
        -2.473, -3.853;
        -2.246, -4.08;
        -2.15, -4.276
];
    };
    

  for i = 1:length(puncteControl)
        segment = puncteControl{i};
        

        PCX = [PCX, segment(:,1)', NaN];  
        PCY = [PCY, segment(:,2)', NaN];
        

        [curbaX, curbaY] = generareCurbaBezier(segment, numPuncte);
        BX = [BX, curbaX, NaN];  
        BY = [BY, curbaY, NaN];
    end
end