function [BX, BY, PCX, PCY] = NasCuPoligoane(numPuncte)

    BX = [];
    BY = [];
    PCX = []; 
    PCY = []; 
 

 puncteControl = {
 [
    -0.15, 0.87;
     1.675, 1.393;
     1.525, -0.51;
     0.344, -0.867
];
[
     -0.15, 0.87;
     -1.32, 0.537;
     -0.455, -0.83;
      0.344, -0.867
];
    };
    
 for i = 1:length(puncteControl)
        segment = puncteControl{i};
        

        PCX = [PCX, segment(:,1)', NaN];  
        PCY = [PCY, segment(:,2)', NaN];
      
        [curbaX, curbaY] = generareCurbaBezier(segment, numPuncte);
        BX = [BX, curbaX, NaN];  
        BY = [BY, curbaY, NaN];
    end
end