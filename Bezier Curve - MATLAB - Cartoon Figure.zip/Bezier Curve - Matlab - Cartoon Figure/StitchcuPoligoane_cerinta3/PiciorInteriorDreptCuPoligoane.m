function [BX, BY, PCX, PCY] = PiciorInteriorDreptCuPoligoane(numPuncte)

    BX = [];
    BY = [];
    PCX = []; 
    PCY = []; 

 puncteControl = {
 [
        2.133, -4.296;
        1.844, -5.09;
        2.127, -5.307;
        2.23, -5.55
];
[
        2.133, -4.296;
        2.333, -4.02;
        2.444, -3.843;
        3.005, -3.97
];
    };
    
 
  for i = 1:length(puncteControl)
        segment = puncteControl{i};
        
    
        PCX = [PCX, segment(:,1)', NaN]; 
        PCY = [PCY, segment(:,2)', NaN];
        
   
        [curbaX, curbaY] = generareCurbaBezier(segment, numPuncte);
        BX = [BX, curbaX, NaN]; 
        BY = [BY, curbaY, NaN];
    end
end