function [BX, BY, PCX, PCY] = CapStitchCuPoligoane(numPuncte)
    % vectorii de coordonate pentru curba Bezier si pentru punctele poligonului de control
    BX = [];
    BY = [];
    PCX = []; % coordonatele X ale punctelor de control
    PCY = []; % coordonatele Y ale punctelor de control

    puncteControl = {
        [2.66, 1.76; 3.05, 0.916; 2.995, 0.752; 3.038, 0.196];
        [2.66, 1.76; 2.3, 2.317; 2.17, 2.774; 1.17, 3.286];
        [0.25, 3.791; 0.307, 3.21; 0.845, 3.48; 1.17, 3.286];
        [0.25, 3.791; 0.168, 3.636; 0.187, 3.73; 0.096, 3.5];
        [-0.384, 3.695; -0.153, 3.83; -0.096, 3.656; 0.096, 3.5];
        [-0.384, 3.695; -0.348, 3.551; -0.149, 3.567; -0.21, 3.455];
        [-0.629, 3.409; -0.632, 3.433; -0.422, 3.493; -0.21, 3.455];
        [-0.629, 3.409; -0.5834, 3.4007; -0.4463, 3.31; -0.4, 3.307];
        [-1.84, 2.2; -1.292, 3.134; -0.4463, 3.31; -0.4, 3.307];
        [-1.84, 2.2; -2.425, 1.18; -2.56, 0.674; -2.29, -0.626];
        [2.86, -0.45; 1.275, -1.74; -1.43, -1.696; -2.29, -0.626];
        [2.86, -0.45; 2.992, -0.263; 2.996, -0.298; 3.043, 0.262]
    };

   for i = 1:length(puncteControl)
        segment = puncteControl{i};
        
        % Adaugam coordonatele punctelor de control la PCX si PCY
        PCX = [PCX, segment(:,1)', NaN];  % NaN pentru separare 
        PCY = [PCY, segment(:,2)', NaN];
        
        % Calculam si adaugam coordonatele curbei Bezier la BX si BY
        [curbaX, curbaY] = generareCurbaBezier(segment, numPuncte);
        BX = [BX, curbaX, NaN];  % NaN pentru separare 
        BY = [BY, curbaY, NaN];
    end