function [X, Y] = UrecheStangaStitch(numPuncte)
    %vectorii de coordonate
    X = [];
    Y = [];
    
 puncteControl = {
        [-2.82, 4.777; -2.42, 4.224; -2.825, 2.13; -2.306, 1.24];
        [-2.82, 4.777; -3.134, 4.873; -3.58, 4.435; -3.81, 3.627];
        [-3.896, 2.995; -3.557, 3.22; -3.357, 3.003; -3.81, 3.627];
        [-3.896, 2.995; -4.073, 1.304; -3.38, 0.45; -2.42, -0.22]
    };
    

    for i = 1:length(puncteControl)
        [BX, BY] = generareCurbaBezier(puncteControl{i}, numPuncte);
       if i > 1 
           X = [X, NaN];
           Y = [Y, NaN];
        end
        X = [X, BX];
        Y = [Y, BY];
    end
end

function [BX, BY] = generareCurbaBezier(puncteControl, numPuncte)
   BX = zeros(1, numPuncte);
   BY = zeros(1, numPuncte);
    
    for i = 1:numPuncte
        t = (i-1) / (numPuncte-1);
        B = (1-t)^3 * puncteControl(1,:) + ...
            3*(1-t)^2 * t * puncteControl(2,:) + ...
            3*(1-t) * t^2 * puncteControl(3,:) + ...
            t^3 * puncteControl(4,:);
        
        BX(i) = B(1);
        BY(i) = B(2);
end
end