function [X, Y] = ParPiept(numPuncte)
    % vectorii de coordonate
    X = [];
    Y = [];
    
    
    puncteControl = {
        [0.148, -1.525; -0.21, -1.89; 0.212, -1.727; 0.222, -1.736];
        [0.222, -1.736; -0.124, -2.411; 0.272, -2.13; 0.353, -1.996];
        [0.353, -1.996; 0.026, -2.674; 0.323, -2.716; 0.44, -2.101];
        [0.44, -2.101; 0.344, -2.657; 0.318, -2.646; 0.291, -2.743];
    };

  for i = 1:length(puncteControl)
        [BX, BY] = generareCurbaBezier(puncteControl{i}, numPuncte);
        if i > 1 
            X = [X, NaN];
            Y = [Y, NaN];
        end
        X = [X, BX];
        Y = [Y, BY];
    end
end

function [BX, BY] = generareCurbaBezier(puncteControl, numPuncte)
    
    BX = zeros(1, numPuncte);
    BY = zeros(1, numPuncte);
    
    for i = 1:numPuncte
        t = (i-1) / (numPuncte-1); % Parametrul t (intre 0 si 1)
        
        % Calculul coordonatelor pe curba folosind
        % formula Bezier cubica 
        B = (1-t)^3 * puncteControl(1,:) + ...
            3*(1-t)^2 * t * puncteControl(2,:) + ...
            3*(1-t) * t^2 * puncteControl(3,:) + ...
            t^3 * puncteControl(4,:);
        
        BX(i) = B(1);
        BY(i) = B(2);
    end
    
end


