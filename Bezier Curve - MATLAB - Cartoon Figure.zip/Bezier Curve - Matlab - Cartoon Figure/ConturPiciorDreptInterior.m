function [X, Y] = ConturPiciorDreptInterior(numPuncte)
    % vectorii de coordonate
    X = [];
    Y = [];
    
    % Oglindire(de la piciorul stang)  
    puncteControl1 = [
        2.133, -4.296;
        1.844, -5.09;
        2.127, -5.307;
        2.23, -5.55
    ];

    puncteControl2 = [
        2.133, -4.296;
        2.333, -4.02;
        2.444, -3.843;
        3.005, -3.97
    ];

  
    [BX1, BY1] = generareCurbaBezier(puncteControl1, numPuncte);
    X = [X, BX1, NaN]; % Separa segmentele cu NaN
    Y = [Y, BY1, NaN];

    [BX2, BY2] = generareCurbaBezier(puncteControl2, numPuncte);
    X = [X, BX2];
    Y = [Y, BY2];
end
function [BX, BY] = generareCurbaBezier(puncteControl, numPuncte)
    BX = zeros(1, numPuncte);
    BY = zeros(1, numPuncte);
    
    for i = 1:numPuncte
        t = (i-1) / (numPuncte-1);
        B = (1-t)^3 * puncteControl(1,:) + ...
            3*(1-t)^2 * t * puncteControl(2,:) + ...
            3*(1-t) * t^2 * puncteControl(3,:) + ...
            t^3 * puncteControl(4,:);
        
        BX(i) = B(1);
        BY(i) = B(2);
    end
end
