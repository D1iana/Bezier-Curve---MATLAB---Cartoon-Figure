function [X, Y] = ConturOchiStang(numPuncte)
    % vectorii de coordonate
    X = [];
    Y = [];
    
    puncteControl1 = [
        -0.87, -0.02;
        -0.93, 0.615;
        -0.925, 2.804;
        -1.72, 2.39
    ];

    puncteControl2 = [
        -0.87, -0.02;
        -0.933, -0.754;
        -2.05, -0.76;
        -2.40, 0.015 
    ];


    [BX1, BY1] = generareCurbaBezier(puncteControl1, numPuncte);
    X = [X, BX1, NaN]; %NaN pentru a separa cele doua segmente
    Y = [Y, BY1, NaN];

    
    [BX2, BY2] = generareCurbaBezier(puncteControl2, numPuncte);
    X = [X, BX2];
    Y = [Y, BY2];
end

function [BX, BY] = generareCurbaBezier(puncteControl, numPuncte)
    BX = zeros(1, numPuncte);
    BY = zeros(1, numPuncte);
    
    for i = 1:numPuncte
        t = (i-1) / (numPuncte-1);
        B = (1-t)^3 * puncteControl(1,:) + ...
            3*(1-t)^2 * t * puncteControl(2,:) + ...
            3*(1-t) * t^2 * puncteControl(3,:) + ...
            t^3 * puncteControl(4,:);
        
        BX(i) = B(1);
        BY(i) = B(2);
    end
end
