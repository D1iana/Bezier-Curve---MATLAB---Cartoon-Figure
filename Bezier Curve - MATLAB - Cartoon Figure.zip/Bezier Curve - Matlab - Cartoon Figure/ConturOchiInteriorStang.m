function [X, Y] = ConturOchiInteriorStang(numPuncte)
    %vectorii de coordonate
    X = [];
    Y = [];
    
   puncteControl1 = [
        -1.764, 1.436;
        -3.463, 0.256;
        -0.475, -1.777;
        -1.117, 1.004
    ];

    puncteControl2 = [
        -1.764, 1.436;
        -1.514, 1.554;
        -1.217, 1.263;
        -1.117, 1.004
    ];


    [BX1, BY1] = generareCurbaBezier(puncteControl1, numPuncte);
    X = [X, BX1, NaN]; 
    Y = [Y, BY1, NaN];


    [BX2, BY2] = generareCurbaBezier(puncteControl2, numPuncte);
    X = [X, BX2];
    Y = [Y, BY2];
end

function [BX, BY] = generareCurbaBezier(puncteControl, numPuncte)
    BX = zeros(1, numPuncte);
    BY = zeros(1, numPuncte);
    
    for i = 1:numPuncte
        t = (i-1) / (numPuncte-1);
        B = (1-t)^3 * puncteControl(1,:) + ...
            3*(1-t)^2 * t * puncteControl(2,:) + ...
            3*(1-t) * t^2 * puncteControl(3,:) + ...
            t^3 * puncteControl(4,:);
        
        BX(i) = B(1);
        BY(i) = B(2);
    end
end
