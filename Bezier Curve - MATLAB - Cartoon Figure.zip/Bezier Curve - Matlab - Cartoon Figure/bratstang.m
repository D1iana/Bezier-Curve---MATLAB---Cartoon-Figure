function [X, Y] = bratstang(numPuncte)
    % vectorii de coordonate
    X = [];
    Y = [];
    
    % punctele de control pentru bratul stang
    puncteControl = {
        [-1.55, -4.89; -2.01, -1.07; -0.39, 0.98; -0.33, -5.13];
        [-1.55, -4.89; -0.9, -6.38; -0.39, -5.51; -0.33, -5.13]
    };
    
   
    for i = 1:length(puncteControl)
        [BX, BY] = generareCurbaBezier(puncteControl{i}, numPuncte);
        if i > 1 % intrerupe desenarea intre segmente cu NaN
            X = [X, NaN];
            Y = [Y, NaN];
        end
        X = [X, BX];
        Y = [Y, BY];
    end
end
function [BX, BY] = generareCurbaBezier(puncteControl, numPuncte)
    BX = zeros(1, numPuncte);
    BY = zeros(1, numPuncte);
    
    for i = 1:numPuncte
        t = (i-1) / (numPuncte-1);
        B = (1-t)^3 * puncteControl(1,:) + ...
            3*(1-t)^2 * t * puncteControl(2,:) + ...
            3*(1-t) * t^2 * puncteControl(3,:) + ...
            t^3 * puncteControl(4,:);
        
        BX(i) = B(1);
        BY(i) = B(2);
    end
end

