function [X, Y] = GuraStitch(numPuncte)
    % vectorii de coordonate
    X = [];
    Y = [];
    
    % punctele de control pentru prima parte a gurii
    puncteControl1 = [
        -1.855, -0.953;
        -1.7, -0.167;
        -0.64, -1.535;
        1.57, -0.65
    ];

    % punctele de control pentru a doua parte a gurii
    puncteControl2 = [
        2.596, -0.62;
        2.38, -0.167;
        2.035, -0.5;
        1.57, -0.65
    ];


    [BX1, BY1] = generareCurbaBezier(puncteControl1, numPuncte);
    X = [X, BX1, NaN]; 
    Y = [Y, BY1, NaN];


    [BX2, BY2] = generareCurbaBezier(puncteControl2, numPuncte);
    X = [X, BX2];
    Y = [Y, BY2];
end

function [BX, BY] = generareCurbaBezier(puncteControl, numPuncte)
    BX = zeros(1, numPuncte);
    BY = zeros(1, numPuncte);
    
    for i = 1:numPuncte
        t = (i-1) / (numPuncte-1);
        B = (1-t)^3 * puncteControl(1,:) + ...
            3*(1-t)^2 * t * puncteControl(2,:) + ...
            3*(1-t) * t^2 * puncteControl(3,:) + ...
            t^3 * puncteControl(4,:);
        
        BX(i) = B(1);
        BY(i) = B(2);
    end
end
