%Cerinta 4 - modificare puncte de control
%CURBA 1 - detaliu picior stang, forma de frunza
  p = [
     0.5, 0;  % Punctul de start de la baza frunzei
    0.1, 0.3; % Punct de control pentru partea de jos stanga
    0.3, 1.0; % Punct de control varful frunzei (stanga)
    0.5, 1.2; % Varful frunzei
    0.7, 1.0; % Punct de control pentru varful frunzei (dreapta)
    0.9, 0.3; % Punct de control pentru partea de jos dreapta
    0.5, 0    % Punctul de start (iarasi)
]';

deplasareX = -3.3;
deplasareY = -5.3;
p(1,:) = p(1,:) + deplasareX;
p(2,:) = p(2,:) + deplasareY;

% a, e definesc punctul de control b1 pentru prima portiune a curbei
a = -3; 
e = -5.2; 
% c, d definesc punctul de control bn pentru ultima portiune a curbei
c = -3; 
d = -5.2; 

n = size(p, 2);
n=max(size(p));
l=zeros(2,n-2);
for j=1:(n-2)
l(:,j) = p(:,j+2) - p(:,j);
end
ultim=3*(n-1)+1;
b= ones(2,ultim);
b(:,1) = p(:,1);
b(:,2) = [a;e];
b(:,3) = p(:,2)-(1/6)*l(:,1);
for k=1:(n-3)
b(:,3*k+1) = p(:,k+1);
b(:,3*k+2) = p(:,k+1) + (1/6) *l(:,k);
b(:,3*k+3) = p(:,k+2) - (1/6) *l(:,k+1);
end
b(:,3*(n-2)+1) = p(:,n-1);
b(:,3*(n-2)+2) = p(:,n-1) + (1/6) *l(:,n-2);
b(:,3*(n-2)+3) = [c,d];
b(:,ultim) = p(:,n);
i=1;
nr=1;
ng=n-1;
while nr<=ng
plot(b(1,i:i+3), b(2,i:i+3),'kx-');
hold on;
nr=nr+1;
i=i+3;

end
t=0:.001:1; 
B0=(1-t).^3;
B1=3.*(1-t).^2.*t;
B2=3.*(1-t).*t.^2;
B3=t.^3;
B=[B0;B1;B2;B3];
m=length(t);
x=zeros(2,m);
i=1;
nr=1;
while nr<=ng
x=b(:,i:i+3)*B;
plot(x(1,:),x(2,:)); 
nr=nr+1;
i=i+3;
end
for k=l:ng
end
