function [X, Y] = UrecheDreaptaStitch(numPuncte)
    %vectorii de coordonate
    X = [];
    Y = [];


 puncteControl = {
        [3.05, 0.224; 3.89, 0.997; 3.644, 0.827; 3.937, 1.216];
        [ 3.937, 1.216; 3.803, 1.529; 3.333, 1.861; 4.122, 1.733];
        [4.122, 1.733; 4.824, 3.69; 3.72, 5.567; 2.893, 5.434];
        [2.893, 5.434; 2.38, 4.93; 3.17, 3.1; 2.72, 1.616];
        
    };
 
    
   for i = 1:length(puncteControl)
        [BX, BY] = generareCurbaBezier(puncteControl{i}, numPuncte);
        if i > 1 
            X = [X, NaN];
            Y = [Y, NaN];
        end
        X = [X, BX];
        Y = [Y, BY];
    end
end

function [BX, BY] = generareCurbaBezier(puncteControl, numPuncte)
    %  vectorii pentru coordonatele punctelor de pe curba
    BX = zeros(1, numPuncte);
    BY = zeros(1, numPuncte);
    
    for i = 1:numPuncte
        t = (i-1) / (numPuncte-1); 
        % Calculul coordonatelor punctulelor folosind formula Bezier cubica
        BX(i) = (1-t)^3 * puncteControl(1,1) + ...
                3*(1-t)^2 * t * puncteControl(2,1) + ...
                3*(1-t) * t^2 * puncteControl(3,1) + ...
                t^3 * puncteControl(4,1);
        BY(i) = (1-t)^3 * puncteControl(1,2) + ...
                3*(1-t)^2 * t * puncteControl(2,2) + ...
                3*(1-t) * t^2 * puncteControl(3,2) + ...
                t^3 * puncteControl(4,2);
end
end