function [X, Y] = PiciorStangStitch(numPuncte)
    X = [];
    Y = [];
    
    puncteControl = {
        [-1.56, -2.54; -1.91, -4.66; -1.916, -3.09; -3.1, -4.035];
        [-1.36, -5.41; -2.17, -5.63; -4.05, -6.09; -3.1, -4.035]
    };
    
    for i = 1:length(puncteControl)
        [BX, BY] = generareCurbaBezier(puncteControl{i}, numPuncte);
        if i > 1
            X = [X, NaN]; % Separa segmentele curbelor
            Y = [Y, NaN];
        end
        X = [X, BX];
        Y = [Y, BY];
    end
end
function [BX, BY] = generareCurbaBezier(puncteControl, numPuncte)
    BX = zeros(1, numPuncte);
    BY = zeros(1, numPuncte);
    
    for i = 1:numPuncte
        t = (i-1) / (numPuncte-1);
        B = (1-t)^3 * puncteControl(1,:) + ...
            3*(1-t)^2 * t * puncteControl(2,:) + ...
            3*(1-t) * t^2 * puncteControl(3,:) + ...
            t^3 * puncteControl(4,:);
        
        BX(i) = B(1);
        BY(i) = B(2);
    end
end


