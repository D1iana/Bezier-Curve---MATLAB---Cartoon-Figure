function [X, Y] = CapStitch(numPuncte)
    % vectorii de coordonate
    X = [];
    Y = [];
    
    % puncte de control pentru cap
    puncteControl = {
        [2.66, 1.76; 3.05, 0.916; 2.995, 0.752; 3.038, 0.196];
        [2.66, 1.76; 2.3, 2.317; 2.17, 2.774; 1.17, 3.286];
        [0.25, 3.791; 0.307, 3.21; 0.845, 3.48; 1.17, 3.286];
        [0.25, 3.791; 0.168, 3.636; 0.187, 3.73; 0.096, 3.5];
        [-0.384, 3.695; -0.153, 3.83; -0.096, 3.656; 0.096, 3.5];
        [-0.384, 3.695; -0.348, 3.551; -0.149, 3.567; -0.21, 3.455];
        [-0.629, 3.409; -0.632, 3.433; -0.422, 3.493; -0.21, 3.455];
        [-0.629, 3.409; -0.5834, 3.4007; -0.4463, 3.31; -0.4, 3.307];
        [-1.84, 2.2; -1.292, 3.134; -0.4463, 3.31; -0.4, 3.307];
        [-1.84, 2.2; -2.425, 1.18; -2.56, 0.674; -2.29, -0.626];
        [2.86, -0.45; 1.275, -1.74; -1.43, -1.696; -2.29, -0.626];
        [2.86, -0.45; 2.992, -0.263; 2.996, -0.298; 3.043, 0.262]
    };
    
   
    for i = 1:length(puncteControl)
        [BX, BY] = generareCurbaBezier(puncteControl{i}, numPuncte);
        if i > 1 % intrerupere segmente cu NaN
            X = [X, NaN];
            Y = [Y, NaN];
        end
        X = [X, BX];
        Y = [Y, BY];
    end
end

function [BX, BY] = generareCurbaBezier(puncteControl, numPuncte)
    % vectorii pentru coordonatele punctelor de pe curba
    BX = zeros(1, numPuncte);
    BY = zeros(1, numPuncte);
    
    % Itereaza prin nr de puncte pentru a genera curba
    for i = 1:numPuncte
        t = (i-1) / (numPuncte-1); % Parametrul t (intre 0 si 1)
        
        % Calculul coordonatelor punctului curent pe curba folosind
        % formula Bezier cubica bazata pe punctele de control
        B = (1-t)^3 * puncteControl(1,:) + ...
            3*(1-t)^2 * t * puncteControl(2,:) + ...
            3*(1-t) * t^2 * puncteControl(3,:) + ...
            t^3 * puncteControl(4,:);
        
        BX(i) = B(1);
        BY(i) = B(2);
    end
    
end

