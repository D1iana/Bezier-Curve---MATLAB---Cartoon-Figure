function [P, intermediar] = Casteljau(puncteControl, t)
    n = size(puncteControl, 1) - 1;
    intermediar = cell(1, n);  % Pentru stocarea etapelor intermediare
    Q = puncteControl;
    intermediar{1} = Q;  % Stocam setul initial de puncte de control

    for k = 1:n
        Q_nou = zeros(size(Q,1)-1, 2); % următorul set de puncte
        for i = 1:size(Q,1)-1
            Q_nou(i, :) = (1-t) * Q(i, :) + t * Q(i+1, :);
        end
        Q = Q_nou;  % Actualizam punctele de control pentru pasul urmator
        intermediar{k+1} = Q;  %  noile puncte
    end
    P = Q(1, :);  % Punctul final pe curba a lui t
end
