% punctele de control pentru prima parte a gurii
puncteControl1 = [
    -1.855, -0.953;
    -1.7, -0.167;
    -0.64, -1.535;
    1.57, -0.65
];

% punctele de control pentru a doua parte a gurii
puncteControl2 = [
    2.596, -0.62;
    2.38, -0.167;
    2.035, -0.5;
    1.57, -0.65
];

deseneazaGuraSiMatriceaCasteljeau(puncteControl1, puncteControl2, 100);
