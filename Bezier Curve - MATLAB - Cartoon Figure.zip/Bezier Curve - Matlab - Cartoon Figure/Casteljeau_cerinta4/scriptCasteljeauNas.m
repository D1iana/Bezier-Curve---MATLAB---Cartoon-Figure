% Definirea punctelor de control 
puncteControl1 = [
    -0.15, 0.87;
    1.675, 1.393;
    1.525, -0.51;
    0.344, -0.867
];

puncteControl2 = [
    -0.15, 0.87;
    -1.32, 0.537;
    -0.455, -0.83;
    0.344, -0.867
];


deseneazaNasSiMatriceaCasteljau(puncteControl1, puncteControl2, 100);

