function deseneazaGuraSiMatriceaCasteljeau(puncteControl1, puncteControl2, numPuncte)
    figure; 
    hold on;
    t_values = linspace(0, 1, numPuncte);
    
    % prima parte a gurii
    for i = 1:numPuncte
        [P, intermediar] = Casteljau(puncteControl1, t_values(i));
        for k = 1:length(intermediar)
            etapa = intermediar{k};
            plot(etapa(:,1), etapa(:,2), 'o-', 'MarkerSize', 6, 'LineWidth', 1, 'Color', '#FF00FF');
        end
        plot(P(1), P(2), '.r', 'MarkerSize', 15);
    end
    
    % a doua parte a gurii
    for i = 1:numPuncte
        [P, intermediar] = Casteljau(puncteControl2, t_values(i));
        for k = 1:length(intermediar)
            etapa = intermediar{k};
            plot(etapa(:,1), etapa(:,2), 'o-', 'MarkerSize', 6, 'LineWidth', 1, 'Color', '#FF00FF');
        end
        plot(P(1), P(2), '.b', 'MarkerSize', 15);
    end
    
    %  curba Bezier completa
    curbaX = zeros(1, numPuncte);
    curbaY = zeros(1, numPuncte);
    
    % prima parte
    for i = 1:numPuncte
        [P, ~] = Casteljau(puncteControl1, t_values(i));
        curbaX(i) = P(1);
        curbaY(i) = P(2);
    end
    plot(curbaX, curbaY, 'k', 'LineWidth', 2);
    
    % a doua parte
    for i = 1:numPuncte
        [P, ~] = Casteljau(puncteControl2, t_values(i));
        curbaX(i) = P(1);
        curbaY(i) = P(2);
    end
    plot(curbaX, curbaY, 'g', 'LineWidth', 2);
    
    hold off;
    title('Gura lui Stitch - Algoritmul lui Casteljeau si elementele matricii sistolice ');
end
