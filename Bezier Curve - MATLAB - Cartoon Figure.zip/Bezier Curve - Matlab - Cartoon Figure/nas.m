function [X, Y] = nas(numPuncte)
    %vectorii de coordonate
   X = [];
    Y = [];
    
 puncteControl1 = [
        -0.15, 0.87;
        1.675, 1.393;
       1.525, -0.51;
        0.344, -0.867
    ];

  puncteControl2 = [
        -0.15, 0.87;
        -1.32, 0.537;
        -0.455, -0.83;
        0.344, -0.867
    ];


    [BX1, BY1] = generareCurbaBezier(puncteControl1, numPuncte);
    X = [X, BX1, NaN]; 
    Y = [Y, BY1, NaN];

    [BX2, BY2] = generareCurbaBezier(puncteControl2, numPuncte);
    X = [X, BX2];
    Y = [Y, BY2];
end

function [BX, BY] = generareCurbaBezier(puncteControl, numPuncte)
   BX = zeros(1, numPuncte);
    BY = zeros(1, numPuncte);
    
    for i = 1:numPuncte
        t = (i-1) / (numPuncte-1);
        B = (1-t)^3 * puncteControl(1,:) + ...
            3*(1-t)^2 * t * puncteControl(2,:) + ...
           3*(1-t) * t^2 * puncteControl(3,:) + ...
            t^3 * puncteControl(4,:);
        
        BX(i) = B(1);
        BY(i) = B(2);
    end
end
